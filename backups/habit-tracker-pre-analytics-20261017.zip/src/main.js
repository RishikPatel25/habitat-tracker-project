import { calculateDashboardAnalytics, buildMonthlyReportData, getDaysInMonth, getWeekRanges, getMonthKey as getKey, localISO, dateFor, isScheduled as scheduled } from './features/analytics/calculations.js';
import { createCharts } from './features/analytics/charts.js';
import { parseHabits, SUGGEST } from './features/habits/habitData.js';
import { createSafeStorage, isPlainObject, earliestCheckedDate, exportLocalData, importLocalData } from './features/storage/localStorage.js';
import { renderWellbeing } from './features/tracking/wellbeing.js';
import { THEME_DEFAULT, THEME_PALETTES, THEME_SWATCHES, validHex, normalizeTheme, paletteFor, rgbFromHex, accentForeground } from './features/themes/palette.js';


let currentYear=new Date().getFullYear(),currentMonth=new Date().getMonth(),habits=[],archivedHabits=[],moodData={},sleepData={};
let charts=null;
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim();
let themeSettings={...THEME_DEFAULT},themeDraft=null,themeReturnFocus=null;
function applyTheme(t){const root=document.documentElement,p=paletteFor(t),fg=accentForeground(t.accent),rgb=rgbFromHex(t.accent);root.dataset.theme=t.appearance;root.dataset.density=t.density;
  const vars={'--bg':p.background,'--surf':p.surface,'--surface':p.surface,'--surface-secondary':`color-mix(in srgb, ${p.surface} 88%, ${p.text})`,'--tx':p.text,'--text-primary':p.text,'--mut':p.muted,'--text-secondary':p.muted,'--body-text':p.bodyText,'--body-muted':p.bodyMuted,'--line':p.border,'--border':p.border,'--chart-grid':p.border,'--accent':t.accent,'--accent-foreground':fg,'--rgb':rgb,'--inv':fg,'--glow':t.accent,'--success':t.preset==='sage'?'#557c66':'#4d9b75','--cell':`color-mix(in srgb, ${p.text} 5%, transparent)`,'--gl-top':t.appearance==='light'?'rgba(255,255,255,.4)':'rgba(255,255,255,.35)','--gl-bot':t.appearance==='light'?'rgba(255,255,255,0)':'rgba(0,0,0,.26)'};for(const [k,v]of Object.entries(vars))root.style.setProperty(k,v);
  if(charts){charts.rebuild();renderMentalMetrics();recalculateStatsAndCharts()}}
function syncThemeControls(t){$('themePreset').value=t.preset;$('themeAppearance').value=t.appearance;$('themeAccent').value=t.accent;$('themeBackground').value=t.background;$('themeSurface').value=t.surface;$('themeDensity').value=t.density;document.querySelectorAll('.swatch').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===t.accent.toLowerCase())))}
function paintThemeDraft(){applyTheme(themeDraft);syncThemeControls(themeDraft)}
function chooseThemePreset(preset){if(!THEME_PALETTES[preset])return;themeDraft.preset=preset;const p=THEME_PALETTES[preset];themeDraft.appearance=preset==='clean-light'||preset==='sage'?'light':'dark';themeDraft.background=p[themeDraft.appearance][0];themeDraft.surface=p[themeDraft.appearance][1];themeDraft.accent=p[themeDraft.appearance][5];paintThemeDraft()}
function chooseAppearance(appearance){if(!['light','dark'].includes(appearance))return;themeDraft.appearance=appearance;const p=THEME_PALETTES[themeDraft.preset][appearance];themeDraft.background=p[0];themeDraft.surface=p[1];paintThemeDraft()}
function setAccentColor(color){if(!validHex(color))return;themeDraft.accent=color;applyTheme(themeDraft);document.querySelectorAll('.swatch').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===color.toLowerCase())))}
function initThemeControls(){THEME_SWATCHES.forEach(color=>{const b=document.createElement('button');b.type='button';b.className='swatch';b.dataset.color=color;b.style.backgroundColor=color;b.title=`Accent ${color}`;b.setAttribute('aria-label',`Use accent color ${color}`);b.setAttribute('aria-pressed','false');b.onclick=()=>setAccentColor(color);$('themeSwatches').appendChild(b)});
  $('themePreset').onchange=e=>chooseThemePreset(e.target.value);$('themeAppearance').onchange=e=>chooseAppearance(e.target.value);$('themeAccent').oninput=e=>setAccentColor(e.target.value);$('themeBackground').oninput=e=>{themeDraft.background=e.target.value;applyTheme(themeDraft)};$('themeSurface').oninput=e=>{themeDraft.surface=e.target.value;applyTheme(themeDraft)};$('themeDensity').onchange=e=>{themeDraft.density=e.target.value;applyTheme(themeDraft)};
}
function openThemeSettings(){themeReturnFocus=document.activeElement;themeDraft={...themeSettings};syncThemeControls(themeDraft);const m=$('themeModal');m.classList.add('open');m.setAttribute('aria-hidden','false');$('customizeThemeBtn').setAttribute('aria-expanded','true');setTimeout(()=>$('themePreset').focus(),0)}
function closeThemeSettings(){const m=$('themeModal');if(!m.classList.contains('open'))return;m.classList.remove('open');m.setAttribute('aria-hidden','true');$('customizeThemeBtn').setAttribute('aria-expanded','false');themeDraft=null;applyTheme(themeSettings);(themeReturnFocus||$('customizeThemeBtn')).focus()}
function saveThemeSettings(){const next=normalizeTheme(themeDraft);if(!write('ht_theme_settings',next))return;themeSettings=next;write('ht_theme',next.appearance);closeThemeSettings()}
function resetThemeDraft(){themeDraft={...THEME_DEFAULT};paintThemeDraft();saveThemeSettings()}
function loadThemeSettings(){let legacy=null;try{legacy=localStorage.getItem('ht_theme')}catch(e){}const saved=read('ht_theme_settings',null);themeSettings=normalizeTheme(saved,legacy);if(saved===null)write('ht_theme_settings',themeSettings);applyTheme(themeSettings);initThemeControls()}
function handleThemeKeys(e){if(!$('themeModal').classList.contains('open'))return;if(e.key==='Escape'){e.preventDefault();closeThemeSettings();return}if(e.key==='Tab'){const focusable=[...$('themeModal').querySelectorAll('button:not([disabled]),select:not([disabled]),input:not([disabled])')];if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}
window.addEventListener('keydown',handleThemeKeys);
let focusMode=false;
function setFocusMode(enabled,persist=false){focusMode=!!enabled;$('app').classList.toggle('focus-mode',focusMode);const b=$('focusModeBtn');b.setAttribute('aria-pressed',String(focusMode));b.textContent=focusMode?'Exit focus':'Focus';b.title=focusMode?'Exit Focus mode (F)':'Focus mode shortcut: F';if(persist)write('ht_focus_mode',focusMode)}
function toggleFocusMode(){setFocusMode(!focusMode,true)}
function handleAppShortcuts(e){if(e.altKey||e.ctrlKey||e.metaKey)return;const tag=e.target?.tagName?.toLowerCase();if(['input','textarea','select'].includes(tag)||e.target?.isContentEditable||$('themeModal').classList.contains('open'))return;if(e.key.toLowerCase()==='f'){e.preventDefault();toggleFocusMode()}else if(e.key.toLowerCase()==='a'){e.preventDefault();focusAdd()}}
window.addEventListener('keydown',handleAppShortcuts);

function storageWarning(message){let el=$('storageWarning');if(!el){el=document.createElement('div');el.id='storageWarning';el.setAttribute('role','status');el.style.cssText='position:fixed;bottom:12px;left:12px;z-index:100;max-width:440px;padding:10px 14px;background:#8b2626;color:white;border-radius:6px';document.body.appendChild(el)}el.textContent=message;el.hidden=false}

const safeStorage=createSafeStorage(storageWarning),read=safeStorage.read,write=safeStorage.write,validObject=isPlainObject;
function populateDateSelectors(){const ys=$('yearSelect'),ms=$('monthSelect'),today=new Date();ys.innerHTML='';for(let y=Math.min(today.getFullYear()-100,currentYear-2);y<=Math.max(today.getFullYear()+100,currentYear+2);y++){const o=document.createElement('option');o.value=y;o.textContent=y;ys.appendChild(o)}ys.value=currentYear;ms.value=currentMonth}

function loadSavedData(){
  loadThemeSettings();
  setFocusMode(read('ht_focus_mode',false)===true,false);
  const rawHabits=read('ht_habits',[]),hasValidHabits=Array.isArray(rawHabits);habits=hasValidHabits?rawHabits.filter(x=>validObject(x)&&x.id&&typeof x.title==='string').map(x=>({...x,emoji:x.emoji||'📌',schedule:Array.isArray(x.schedule)?x.schedule:[0,1,2,3,4,5,6],startDate:x.startDate||'0001-01-01'})):[];
  if(!hasValidHabits)storageWarning('Saved habits could not be validated. Their original browser data was left untouched.');
  archivedHabits=read('ht_archived',[]);if(!Array.isArray(archivedHabits)){storageWarning('Archived habits data is invalid; its original data was left untouched.');archivedHabits=[]}
  window.checksData=read('ht_checks',{});if(!validObject(window.checksData))window.checksData={};else for(const k of Object.keys(window.checksData))if(!validObject(window.checksData[k]))window.checksData[k]={};
  moodData=read('ht_mood',{});if(!validObject(moodData))moodData={};else for(const k of Object.keys(moodData))if(!validObject(moodData[k]))moodData[k]={};
  sleepData=read('ht_sleep',{});if(!validObject(sleepData))sleepData={};else for(const k of Object.keys(sleepData))if(!validObject(sleepData[k]))sleepData[k]={};
  notes=read('ht_notes',[]);if(!Array.isArray(notes))notes=[];else notes=notes.filter(x=>validObject(x)&&typeof x.text==='string');
  let startDatesAdjusted=false;
  for(const h of [...habits,...archivedHabits].filter(validObject)){const first=earliestCheckedDate(h.id,window.checksData);if(first&&first<(h.startDate||'0001-01-01')){h.startDate=first;startDatesAdjusted=true}}
  // Keep the legacy storage keys intact and mark the schema separately for safe, repeatable migrations.
  if(startDatesAdjusted||hasValidHabits&&rawHabits.some(x=>validObject(x)&&(!Array.isArray(x.schedule)||!x.startDate)))saveHabits();
  if(startDatesAdjusted)write('ht_archived',archivedHabits);
  if(read('ht_schema_version',null)===null)write('ht_schema_version',2);
}
const saveHabits=()=>write('ht_habits',habits);
function saveChecks(){write('ht_checks',window.checksData);write('ht_mood',moodData);write('ht_sleep',sleepData)}

const isT=d=>{const t=new Date();return t.getFullYear()===currentYear&&t.getMonth()===currentMonth&&t.getDate()===d};
const isFuture=d=>dateFor(currentYear,currentMonth,d)>dateFor(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());
function goToday(){const t=new Date();currentYear=t.getFullYear();currentMonth=t.getMonth();populateDateSelectors();updateCalendar()}
function shiftMonth(delta){const d=new Date(currentYear,currentMonth+delta,1);currentYear=d.getFullYear();currentMonth=d.getMonth();populateDateSelectors();updateCalendar()}
function updateCalendar(){
  currentYear=+$('yearSelect').value;currentMonth=+$('monthSelect').value;
  if(!Number.isFinite(currentYear)||currentMonth<0||currentMonth>11)return;
  renderTableHeaders();renderTableBody();renderMentalMetrics();recalculateStatsAndCharts();renderChips();
}
function renderTableHeaders(){
  const n=getDaysInMonth(currentYear,currentMonth),names=['Su','Mo','Tu','We','Th','Fr','Sa'];
  const weeks=getWeekRanges(currentYear,currentMonth);
  $('hr1').innerHTML='<th class="nm">Habits</th>'+weeks.map((week,index)=>`<th colspan="${week.end-week.start+1}" class="wk">Week ${index+1}</th>`).join('')+'<th colspan="2" class="wk">This month</th>';
  let a=`<th class="nm">${habits.length} habits</th>`,b='<th class="nm"></th>';
  for(let d=1;d<=31;d++){
    if(d<=n){a+=`<th>${names[new Date(currentYear,currentMonth,d).getDay()]}</th>`;b+=`<th${isT(d)?' class="today-head" title="Today"':''}>${d}</th>`}
    else{a+='<th></th>';b+='<th></th>'}
  }
  a+='<th class="wk month-done-head">Done</th><th class="month-rate-head">Rate</th>';b+='<th class="wk month-done-head"></th><th class="month-rate-head"></th>';
  $('hr2').innerHTML=a;$('hr3').innerHTML=b;
}
function renderTableBody(){
  const tb=$('habitsTableBody'),n=getDaysInMonth(currentYear,currentMonth),mk=getKey(currentYear,currentMonth);
  tb.innerHTML='';
  if(!validObject(window.checksData[mk]))window.checksData[mk]={};
  habits.forEach(h=>{
    if(!validObject(window.checksData[mk][h.id]))window.checksData[mk][h.id]={};
    const tr=document.createElement('tr');
    tr.innerHTML=`<td class="nm"><div class="hn"><span title="${esc(h.title)}"><em>${esc(h.emoji)}</em>&nbsp; ${esc(h.title)}</span><button aria-label="Edit ${esc(h.title)}" title="Edit habit" onclick="editHabit('${h.id}')">✎</button><button aria-label="Archive ${esc(h.title)}" title="Archive habit" onclick="archiveHabit('${h.id}')">⇩</button><button aria-label="Delete ${esc(h.title)}" title="Delete habit" onclick="deleteHabit('${h.id}')">&times;</button></div></td>`;
    for(let d=1;d<=31;d++){
      const td=document.createElement('td');
      if(d<=n){
        const c=document.createElement('input');c.type='checkbox';c.className='chk';c.checked=!!window.checksData[mk][h.id][d];const date=dateFor(currentYear,currentMonth,d),future=isFuture(d),isScheduled=scheduled(h,date);c.disabled=!isScheduled;if(!isScheduled)td.className='off';else if(future)td.className='future';
        c.setAttribute('aria-label',`${h.title}, day ${d}${future?', future date; saved but excluded from progress until that date':''}`);if(future)c.title='Future date: you can pre-mark it, but it will not count toward progress until that date.';
        c.onchange=e=>toggleCheck(h.id,d,e.target.checked);
        td.appendChild(c);if(isT(d))td.className='today';
      }else td.className='off';
      tr.appendChild(td);
    }
    tr.insertAdjacentHTML('beforeend',`<td class="wk dn" id="d_${h.id}"></td><td class="rt" id="r_${h.id}"></td>`);
    tb.appendChild(tr);
  });
  if(!habits.length){const tr=document.createElement('tr');tr.innerHTML='<td colspan="34" class="sub" style="text-align:left;padding:16px">No habits yet. Add one below to start tracking. Your tracker will stay empty until you choose a habit.</td>';tb.appendChild(tr)}
}
function toggleCheck(id,day,v){
  const mk=getKey(currentYear,currentMonth);
  window.checksData[mk]=window.checksData[mk]||{};window.checksData[mk][id]=window.checksData[mk][id]||{};
  window.checksData[mk][id][day]=v;
  const habit=habits.find(h=>h.id===id),date=localISO(dateFor(currentYear,currentMonth,day));
  if(v&&habit&&date<(habit.startDate||'0001-01-01')){habit.startDate=date;saveHabits()}
  saveChecks();recalculateStatsAndCharts();
}
function renderMentalMetrics(){renderWellbeing({year:currentYear,month:currentMonth,moodData,sleepData,isFuture,save:saveChecks,css,warn:storageWarning,$})}
function monthlyReportData(year=currentYear,month=currentMonth){return buildMonthlyReportData({habits,archivedHabits,checksData:window.checksData,moodData,sleepData,year,month,now:new Date()})}
function downloadMonthlyReport(){
  const r=monthlyReportData(),gradeTone=r.grade.mark==='A+'||r.grade.mark==='A'?'great':r.grade.mark==='N/A'?'none':'grade';
  const pct=v=>v===null?'—':`${v}%`,bar=v=>v===null?'0%':`${v}%`;
  const habitsHtml=r.rows.length?r.rows.map(h=>`<tr><td><span class="habit-icon">${esc(h.emoji)}</span><strong>${esc(h.title)}</strong>${h.category?`<small>${esc(h.category)}</small>`:''}</td><td>${h.done} / ${h.goal}</td><td>${h.missed}</td><td><div class="track"><i style="width:${bar(h.percent)}"></i></div><span class="percent">${pct(h.percent)}</span></td><td><b class="mini-grade">${h.grade.mark}</b></td></tr>`).join(''):'<tr><td colspan="5" class="empty">No habits are available for this month yet.</td></tr>';
  const report=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(r.monthLabel)} Habit Progress Report</title><style>
*{box-sizing:border-box}body{margin:0;padding:40px 18px;background:#f3f5f7;color:#20252c;font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.report{max-width:900px;margin:auto;background:#fff;border:1px solid #d7dce2;border-radius:16px;padding:34px;box-shadow:0 14px 44px #11131812}header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}h1{font-size:28px;line-height:1.15;margin:0 0 6px;letter-spacing:-.03em}.muted{color:#5b6470}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;font-weight:700;color:#667080}.print{border:0;border-radius:8px;background:#364152;color:white;padding:10px 14px;font:inherit;font-weight:650;cursor:pointer}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:26px 0}.card{padding:16px;border:1px solid #dfe3e8;border-radius:11px;background:#fafbfc}.card span{display:block;font-size:12px;color:#5b6470}.card strong{display:block;margin-top:3px;font-size:25px;line-height:1.15}.grade-card{background:#f3f0ff;border-color:#ded5fa}.grade-card strong{color:#6046a7}.grade-card.great{background:#edf7f0;border-color:#cde5d4}.grade-card.great strong{color:#287249}.grade-card.none{background:#f3f5f7}.progress-line{height:10px;border-radius:10px;background:#e6e9ed;overflow:hidden;margin-top:12px}.progress-line i,.track i{display:block;height:100%;border-radius:inherit;background:#557c66}h2{font-size:17px;margin:27px 0 10px}table{width:100%;border-collapse:collapse;font-size:13px}th{text-align:left;color:#5b6470;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em}td,th{padding:11px 8px;border-bottom:1px solid #e6e9ed}td:first-child{width:34%}td:first-child small{display:block;color:#69727e;margin-left:26px}.habit-icon{display:inline-block;width:22px}.track{display:inline-block;vertical-align:middle;width:min(100px,55%);height:7px;border-radius:9px;background:#e6e9ed;overflow:hidden;margin-right:7px}.track i{background:#557c66}.percent{color:#5b6470}.mini-grade{display:inline-block;min-width:34px;padding:3px 7px;background:#f0f2f5;border-radius:6px;text-align:center}.empty{text-align:center;color:#5b6470;padding:24px}.notes{margin-top:23px;padding:14px 16px;border-radius:10px;background:#f6f7f9;color:#515b67;font-size:13px}.notes p{margin:4px 0}.footer{margin-top:26px;padding-top:14px;border-top:1px solid #e6e9ed;color:#69727e;font-size:11px}@media(max-width:620px){body{padding:12px 8px}.report{padding:20px 14px}.summary{grid-template-columns:repeat(2,1fr)}header{align-items:flex-start}h1{font-size:23px}table{font-size:11px}td,th{padding:9px 4px}.track{width:42px}}@media print{body{padding:0;background:#fff}.report{max-width:none;border:0;border-radius:0;box-shadow:none;padding:0}.print{display:none}.summary{break-inside:avoid}tr{break-inside:avoid}}
</style></head><body><main class="report"><header><div><div class="eyebrow">Habit Tracker · Monthly Report</div><h1>${esc(r.monthLabel)}</h1><p class="muted">${r.endDay?`Progress through ${new Intl.DateTimeFormat(undefined,{month:'short',day:'numeric',year:'numeric'}).format(dateFor(r.year,r.month,r.endDay))}`:'No days in this month have occurred yet.'}</p></div><button class="print" onclick="window.print()">Print / Save as PDF</button></header>
<section class="summary"><div class="card"><span>Progress</span><strong>${pct(r.percent)}</strong><div class="progress-line"><i style="width:${bar(r.percent)}"></i></div></div><div class="card"><span>Completed</span><strong>${r.done}</strong></div><div class="card"><span>Scheduled goal</span><strong>${r.goal}</strong></div><div class="card grade-card ${gradeTone}"><span>Monthly mark</span><strong>${r.grade.mark}</strong><span>${esc(r.grade.label)}</span></div></section>
<h2>Habit breakdown</h2><table><thead><tr><th>Habit</th><th>Done / goal</th><th>Missed</th><th>Progress</th><th>Mark</th></tr></thead><tbody>${habitsHtml}</tbody></table>
<h2>Wellbeing logs</h2><p class="muted">${r.moodAverage===null?'Mood: no valid ratings':`Average mood: ${r.moodAverage.toFixed(1)} / 5`} &nbsp;·&nbsp; ${r.sleepAverage===null?'Sleep: no valid entries':`Average sleep: ${r.sleepAverage.toFixed(1)} hours`}</p>
<aside class="notes"><strong>How this report is scored</strong><p>Progress = completed scheduled habit-days ÷ eligible scheduled habit-days. Only dates on or before the report cutoff count; future dates and rest days are excluded. Missed = scheduled goal minus completed.</p><p>Marks: A+ 95–100%, A 90–94%, B 80–89%, C 70–79%, D 60–69%, F below 60%. A month with no eligible days receives N/A.</p></aside><div class="footer">Generated ${esc(new Intl.DateTimeFormat(undefined,{dateStyle:'long'}).format(new Date()))}. Mood and sleep averages include valid recorded values only and are descriptive summaries.</div></main></body></html>`;
  try{const blob=new Blob([report],{type:'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`habit-report-${r.year}-${String(r.month+1).padStart(2,'0')}.html`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch(e){storageWarning('Could not create the monthly report download in this browser.');}
}
function recalculateStatsAndCharts(){
  const a=calculateDashboardAnalytics({habits,checksData:window.checksData,year:currentYear,month:currentMonth,now:new Date()});
  $('statGoal').textContent=a.monthGoal;$('statCompleted').textContent=a.done;$('statLeft').textContent=a.remaining;$('donutPercent').textContent=a.overallPercent+'%';$('donutSub').textContent=`${a.done} done · ${a.planned} plan`;
  $('statGoal').title='All eligible scheduled habit-days in this month';$('statCompleted').title='Completed scheduled days through today';$('statLeft').title='Scheduled days not completed or pre-marked';
  $('avgDailyRate').textContent='Avg '+Math.round(a.averageDailyRate)+'%';$('statStreak').textContent=a.currentStreak+'d';$('statStreak').title='Longest current streak among active habits';
  window.DP=a.dailyRates;window.LAST=a.latestElapsedDay;charts?.update({dailyBars:a.dailyBars,dailyAverage:a.dailyAverage,plannedDays:a.plannedDays,weekly:a.weekly,overallPercent:a.overallPercent});renderAnalysisTable(a.habitStats);renderTopHabits(a.habitStats);
}
function renderAnalysisTable(st){
  st.forEach(x=>{
    const d=$('d_'+x.id),r=$('r_'+x.id);if(!d)return;
    d.innerHTML=`<b>${x.actual}</b>/${x.goal}<span class="sub" title="Current streak ${x.currentStreak} days; best ${x.bestStreak} days"> · ${x.currentStreak}d</span>`;
    const displayRate=Math.round(x.percentage);
    r.innerHTML=`<span class="bar"><i style="width:${x.percentage}%"></i></span><span class="pc">${displayRate}%</span>`;
  });
}
function renderTopHabits(st){
  window.STATS=st;
  const top=st.length?[...st].sort((a,b)=>b.percentage-a.percentage).slice(0,3).map((x,i)=>`<li><span class="t"><s>${i+1}</s><em>${esc(x.emoji)}</em> ${esc(x.title)}</span><span class="v"><strong>${Math.round(x.percentage)}%</strong><span class="bar"><i style="width:${x.percentage}%"></i></span></span></li>`).join(''):'<li class="sub">Add your first habit below to start tracking.</li>';
  const dp=window.DP||[],last=window.LAST??-1,mk=getKey(currentYear,currentMonth);
  const av=a=>a.reduce((x,y)=>x+y,0)/a.length,names=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const g=[[],[],[],[],[],[],[]];for(let i=0;i<=last;i++)g[new Date(currentYear,currentMonth,i+1).getDay()].push(dp[i]);
  let best=-1,bv=-1;g.forEach((a,k)=>{if(a.length&&av(a)>bv){bv=av(a);best=k}});
  const li=(t,v,sub)=>`<li><span class="t">${t}</span><span class="v"><strong>${v}</strong><span class="sub">${sub}</span></span></li>`;
  const day=best<0?li('Best weekday','–','Log a few days'):li('Best weekday',names[best],Math.round(bv)+'% done on average');
  const hi=[],lo=[];for(let i=0;i<=last;i++){const raw=(sleepData[mk]||{})[i+1];if(raw===''||raw==null||!Number.isFinite(Number(raw))||Number(raw)<0||dp[i]==null)continue;const v=Number(raw);(v>=7?hi:lo).push(dp[i])}
  let sl=li('Sleep of 7h or more','–','Log more nights to compare');
  if(hi.length>=2&&lo.length>=2){const d=Math.round(av(hi)-av(lo));sl=li('Sleep of 7h or more',(d>0?'+':'')+d+'%','habits done vs shorter nights')}
  $('topHabitsList').innerHTML=top+day+sl;
}

/* ---------- Habits & theme ---------- */
function addHabits(text){
  const list=parseHabits(text);if(!list.length)return false;
  const have=new Set(habits.map(h=>h.title.toLowerCase()));
  list.forEach(h=>{const k=h.title.toLowerCase();if(!have.has(k)){h.startDate=localISO(new Date());h.schedule=[0,1,2,3,4,5,6];habits.push(h);have.add(k)}});
  saveHabits();updateCalendar();
  const sc=$('habitsTable').closest('.scroll');sc.scrollTop=sc.scrollHeight;return true;
}
function submitAdd(){const i=$('addInput');if(addHabits(i.value)){i.value='';const b=document.querySelector('.addbtn');b.textContent='Added';setTimeout(()=>b.textContent='Add habit',1100)}i.focus()}
function focusAdd(){$('addInput').focus()}
function renderChips(){
  const have=new Set(habits.map(h=>h.title.toLowerCase()));
  $('chips').innerHTML=SUGGEST.filter(t=>!have.has(t.toLowerCase())).slice(0,4).map(t=>`<button class="chip" onclick="addHabits('${t}')">+ ${t}</button>`).join('');
}
$('addInput').addEventListener('paste',e=>{const t=(e.clipboardData||window.clipboardData).getData('text');if(/[\n,;]/.test(t)){e.preventDefault();addHabits(t)}});
function editHabit(id){const h=habits.find(x=>x.id===id);if(!h)return;const name=prompt('Habit name:',h.title);if(name===null)return;const title=name.trim();if(!title){alert('Habit name cannot be empty.');return}if(habits.some(x=>x.id!==id&&x.title.toLowerCase()===title.toLowerCase())){alert('A habit with that name already exists.');return}const schedule=prompt('Scheduled weekdays (0=Sun … 6=Sat), comma separated:',(h.schedule||[0,1,2,3,4,5,6]).join(','));if(schedule===null)return;const days=[...new Set(schedule.split(',').map(x=>Number(x.trim())).filter(x=>Number.isInteger(x)&&x>=0&&x<=6))];if(!days.length){alert('Choose at least one weekday.');return}const emoji=prompt('Habit icon (emoji):',h.emoji||'📌');if(emoji===null)return;const category=prompt('Category (optional):',h.category||'');if(category===null)return;h.title=title;h.schedule=days;h.emoji=emoji.trim()||'📌';h.category=category.trim();saveHabits();updateCalendar()}
function archiveHabit(id){const h=habits.find(x=>x.id===id);if(!h||!confirm(`Archive “${h.title}”? Historical records will be kept.`))return;habits=habits.filter(x=>x.id!==id);archivedHabits.push({...h,archivedAt:localISO(new Date())});saveHabits();write('ht_archived',archivedHabits);updateCalendar()}
function restoreHabit(){if(!archivedHabits.length){alert('There are no archived habits.');return}const choices=archivedHabits.map((h,i)=>`${i+1}. ${h.title}`).join('\n'),pick=Number(prompt(`Restore an archived habit by number:\n${choices}`));if(!Number.isInteger(pick)||pick<1||pick>archivedHabits.length)return;const h=archivedHabits.splice(pick-1,1)[0];delete h.archivedAt;habits.push(h);saveHabits();write('ht_archived',archivedHabits);updateCalendar()}
function deleteHabit(id){const h=habits.find(x=>x.id===id);if(!h||!confirm(`Permanently remove “${h.title}” from this tracker? Historical completion records will be retained.`))return;habits=habits.filter(x=>x.id!==id);saveHabits();updateCalendar()}
function toggleTheme(){
  const appearance=themeSettings.appearance==='dark'?'light':'dark',p=THEME_PALETTES[themeSettings.preset][appearance];themeSettings={...themeSettings,appearance,background:p[0],surface:p[1]};applyTheme(themeSettings);write('ht_theme_settings',themeSettings);write('ht_theme',appearance);if(themeDraft){themeDraft={...themeSettings};syncThemeControls(themeDraft)}
}

/* ---------- Quick notes ---------- */
let notes=[];
const saveNotes=()=>write('ht_notes',notes);
function renderNotes(){
  const n=notes.length,b=$('noteBadge');
  b.textContent=n>99?'99+':n;b.classList.toggle('show',n>0);
  $('noteCount').textContent=n?'('+n+')':'';
  $('noteList').innerHTML=n?notes.map(x=>`<li><div class="nt">${esc(x.text)}<small>${esc(x.date)}</small></div><button onclick="deleteNote('${x.id}')" aria-label="Delete note" title="Delete">&times;</button></li>`).join(''):'<li class="npempty">No notes yet. Jot down a small task above.</li>';
}
function addNote(){
  const i=$('noteInput'),t=i.value.trim();
  if(t){notes.unshift({id:'n_'+Date.now()+'_'+Math.random().toString(36).slice(2,5),text:t,date:new Date().toLocaleDateString('en-GB',{day:'numeric',month:'short'})});saveNotes();renderNotes();i.value=''}
  i.focus();
}
function deleteNote(id){notes=notes.filter(x=>x.id!==id);saveNotes();renderNotes()}
function toggleNotes(e){
  if(e)e.stopPropagation();
  const p=$('notePop'),open=!p.classList.contains('open');
  p.classList.toggle('open',open);$('noteBtn').setAttribute('aria-expanded',open);
  if(open)setTimeout(()=>$('noteInput').focus(),0);else $('noteBtn').focus();
}
document.addEventListener('click',e=>{const p=$('notePop');if(p.classList.contains('open')&&!e.target.closest('.notewrap'))toggleNotes()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('notePop').classList.contains('open'))toggleNotes()});
notes=read('ht_notes',[]);renderNotes();
function initialize(){loadSavedData();charts=createCharts({css,warn:storageWarning});charts.rebuild();populateDateSelectors();updateCalendar()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize,{once:true});else initialize();

function exportAppData(){try{const blob=new Blob([JSON.stringify(exportLocalData(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`habit-tracker-backup-${localISO(new Date())}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch{storageWarning('Could not export Habit Tracker data in this browser.')}}
function openImportPicker(){$('importDataInput').click()}
async function handleImportFile(event){const file=event.target.files?.[0];if(!file)return;try{const payload=JSON.parse(await file.text());let allowReplace=false;try{allowReplace=confirm('Importing replaces the Habit Tracker data in this browser. A recovery backup will be saved first. Continue?')}catch{}importLocalData(payload,localStorage,{allowReplace});alert('Habit Tracker data imported. The page will reload now.');location.reload()}catch(error){storageWarning(error.message||'Could not import this backup. Existing data was preserved.')}finally{event.target.value=''}}
$('importDataInput')?.addEventListener('change',handleImportFile);
Object.assign(window,{toggleNotes,addNote,shiftMonth,updateCalendar,toggleTheme,openThemeSettings,goToday,downloadMonthlyReport,toggleFocusMode,restoreHabit,focusAdd,submitAdd,closeThemeSettings,resetThemeDraft,saveThemeSettings,editHabit,archiveHabit,deleteHabit,addHabits,deleteNote,exportAppData,openImportPicker});
