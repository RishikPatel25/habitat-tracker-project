import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateDashboardAnalytics, buildMonthlyReportData } from '../src/features/analytics/calculations.js';

const today = new Date(2026, 9, 17, 12);
const habit = { id: 'h1', title: 'Read', emoji: '📖', startDate: '2026-10-01', schedule: [0, 1, 2, 3, 4, 5, 6] };

test('future pre-marks are planned and included in projected month overall, not completed count', () => {
  const result = calculateDashboardAnalytics({ habits: [habit], checksData: { '2026-9': { h1: { 2: true, 17: true, 31: true } } }, year: 2026, month: 9, now: today });
  assert.equal(result.done, 2);
  assert.equal(result.planned, 1);
  assert.equal(result.monthGoal, 31);
  assert.equal(result.remaining, 28);
  assert.equal(result.overallPercent, 10);
  assert.equal(result.dailyRates[16], 100);
});

test('planned checks render in the correct fifth week and day bar', () => {
  const result = calculateDashboardAnalytics({ habits: [habit], checksData: { '2026-9': { h1: { 29: true } } }, year: 2026, month: 9, now: today });
  assert.equal(result.weekly.length, 5);
  assert.equal(result.weekly[4].plannedDone, 1);
  assert.equal(result.weekly[4].plannedGoal, 3);
  assert.equal(result.weekly[4].rate, 33);
  assert.equal(result.dailyBars[28], 100);
  assert.equal(result.dailyRates[28], null);
});

test('a future month has no actual progress until the month begins', () => {
  const result = calculateDashboardAnalytics({ habits: [habit], checksData: {}, year: 2026, month: 11, now: today });
  assert.equal(result.done, 0);
  assert.equal(result.planned, 0);
  assert.equal(result.overallPercent, 0);
  assert.ok(result.dailyRates.every((value) => value === null));
});

test('monthly report excludes future and pre-start checks', () => {
  const result = buildMonthlyReportData({ habits: [{ ...habit, startDate: '2026-10-05' }], archivedHabits: [], checksData: { '2026-9': { h1: { 2: true, 5: true, 17: true, 20: true } } }, moodData: {}, sleepData: {}, year: 2026, month: 9, now: today });
  assert.equal(result.rows[0].goal, 13);
  assert.equal(result.rows[0].done, 2);
  assert.equal(result.rows[0].missed, 11);
});
