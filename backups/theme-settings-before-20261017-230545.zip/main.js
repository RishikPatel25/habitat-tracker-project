import { trackerState, selectMonth } from './features/state/trackerState.js';
import { calculateDashboardAnalytics, buildMonthlyReportData, getDaysInMonth, getWeekRanges, getMonthKey as getKey, localISO, dateFor, isScheduled as scheduled, isValidLocalDate } from './features/analytics/calculations.js';

import { createCharts } from './features/analytics/charts.js';

import { parseHabits, SUGGEST } from './features/habits/habitData.js';
import { addHabitsToState, editHabitInState, archiveHabitInState, restoreHabitInState, deleteHabitFromState, reorderHabitInState, normalizeHabitName } from './features/habits/management.js';

import { createSafeStorage, isPlainObject, earliestCheckedDate, exportLocalData, importLocalData } from './features/storage/localStorage.js';

import { renderWellbeing } from './features/tracking/wellbeing.js';

import { THEME_DEFAULT, THEME_PALETTES, THEME_SWATCHES, validHex, normalizeTheme, paletteFor, rgbFromHex, accentForeground } from './features/themes/palette.js';







let charts=null;

const $=id=>document.getElementById(id);

const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const css=v=>getComputedStyle(document.documentElement).getPropertyValue(v).trim();



function applyTheme(t){const root=document.documentElement,p=paletteFor(t),fg=accentForeground(t.accent),rgb=rgbFromHex(t.accent);root.dataset.theme=t.appearance;root.dataset.density=t.density;

  const vars={'--bg':p.background,'--surf':p.surface,'--surface':p.surface,'--surface-secondary':`color-mix(in srgb, ${p.surface} 88%, ${p.text})`,'--tx':p.text,'--text-primary':p.text,'--mut':p.muted,'--text-secondary':p.muted,'--body-text':p.bodyText,'--body-muted':p.bodyMuted,'--line':p.border,'--border':p.border,'--chart-grid':p.border,'--accent':t.accent,'--accent-foreground':fg,'--rgb':rgb,'--inv':fg,'--glow':t.accent,'--success':t.preset==='sage'?'#557c66':'#4d9b75','--cell':`color-mix(in srgb, ${p.text} 5%, transparent)`,'--gl-top':t.appearance==='light'?'rgba(255,255,255,.4)':'rgba(255,255,255,.35)','--gl-bot':t.appearance==='light'?'rgba(255,255,255,0)':'rgba(0,0,0,.26)'};for(const [k,v]of Object.entries(vars))root.style.setProperty(k,v);

  if(charts){charts.restyle();renderMentalMetrics();recalculateStatsAndCharts()}}

function syncThemeControls(t){$('themePreset').value=t.preset;$('themeAppearance').value=t.appearance;$('themeAccent').value=t.accent;$('themeBackground').value=t.background;$('themeSurface').value=t.surface;$('themeDensity').value=t.density;document.querySelectorAll('.swatch').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===t.accent.toLowerCase())))}

function paintThemeDraft(){applyTheme(trackerState.themeDraft);syncThemeControls(trackerState.themeDraft)}

function chooseThemePreset(preset){if(!THEME_PALETTES[preset])return;trackerState.themeDraft.preset=preset;const p=THEME_PALETTES[preset];trackerState.themeDraft.appearance=preset==='clean-light'||preset==='sage'?'light':'dark';trackerState.themeDraft.background=p[trackerState.themeDraft.appearance][0];trackerState.themeDraft.surface=p[trackerState.themeDraft.appearance][1];trackerState.themeDraft.accent=p[trackerState.themeDraft.appearance][5];paintThemeDraft()}

function chooseAppearance(appearance){if(!['light','dark'].includes(appearance))return;trackerState.themeDraft.appearance=appearance;const p=THEME_PALETTES[trackerState.themeDraft.preset][appearance];trackerState.themeDraft.background=p[0];trackerState.themeDraft.surface=p[1];paintThemeDraft()}

function setAccentColor(color){if(!validHex(color))return;trackerState.themeDraft.accent=color;applyTheme(trackerState.themeDraft);document.querySelectorAll('.swatch').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===color.toLowerCase())))}

function initThemeControls(){THEME_SWATCHES.forEach(color=>{const b=document.createElement('button');b.type='button';b.className='swatch';b.dataset.color=color;b.style.backgroundColor=color;b.title=`Accent ${color}`;b.setAttribute('aria-label',`Use accent color ${color}`);b.setAttribute('aria-pressed','false');b.onclick=()=>setAccentColor(color);$('themeSwatches').appendChild(b)});

  $('themePreset').onchange=e=>chooseThemePreset(e.target.value);$('themeAppearance').onchange=e=>chooseAppearance(e.target.value);$('themeAccent').oninput=e=>setAccentColor(e.target.value);$('themeBackground').oninput=e=>{trackerState.themeDraft.background=e.target.value;applyTheme(trackerState.themeDraft)};$('themeSurface').oninput=e=>{trackerState.themeDraft.surface=e.target.value;applyTheme(trackerState.themeDraft)};$('themeDensity').onchange=e=>{trackerState.themeDraft.density=e.target.value;applyTheme(trackerState.themeDraft)};

}

function openThemeSettings(){trackerState.themeReturnFocus=document.activeElement;trackerState.themeDraft={...trackerState.themeSettings};syncThemeControls(trackerState.themeDraft);const m=$('themeModal');m.classList.add('open');m.setAttribute('aria-hidden','false');$('customizeThemeBtn').setAttribute('aria-expanded','true');setTimeout(()=>$('themePreset').focus(),0)}

function closeThemeSettings(){const m=$('themeModal');if(!m.classList.contains('open'))return;m.classList.remove('open');m.setAttribute('aria-hidden','true');$('customizeThemeBtn').setAttribute('aria-expanded','false');trackerState.themeDraft=null;applyTheme(trackerState.themeSettings);(trackerState.themeReturnFocus||$('customizeThemeBtn')).focus()}

function saveThemeSettings(){const next=normalizeTheme(trackerState.themeDraft);if(!write('ht_theme_settings',next))return;trackerState.themeSettings=next;write('ht_theme',next.appearance);closeThemeSettings()}

function resetThemeDraft(){trackerState.themeDraft={...THEME_DEFAULT};paintThemeDraft();saveThemeSettings()}

function loadThemeSettings(){let legacy=null;try{legacy=localStorage.getItem('ht_theme')}catch(e){}const saved=read('ht_theme_settings',null);trackerState.themeSettings=normalizeTheme(saved,legacy);if(saved===null)write('ht_theme_settings',trackerState.themeSettings);applyTheme(trackerState.themeSettings);initThemeControls()}

function handleThemeKeys(e){if(!$('themeModal').classList.contains('open'))return;if(e.key==='Escape'){e.preventDefault();closeThemeSettings();return}if(e.key==='Tab'){const focusable=[...$('themeModal').querySelectorAll('button:not([disabled]),select:not([disabled]),input:not([disabled])')];if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}

window.addEventListener('keydown',handleThemeKeys);



function setFocusMode(enabled,persist=false){trackerState.focusMode=!!enabled;$('app').classList.toggle('focus-mode',trackerState.focusMode);const b=$('focusModeBtn');b.setAttribute('aria-pressed',String(trackerState.focusMode));b.textContent=trackerState.focusMode?'Exit focus':'Focus';b.title=trackerState.focusMode?'Exit Focus mode (F)':'Focus mode shortcut: F';if(persist)write('ht_focus_mode',trackerState.focusMode)}

function toggleFocusMode(){setFocusMode(!trackerState.focusMode,true)}

function handleAppShortcuts(e){if(e.altKey||e.ctrlKey||e.metaKey)return;const tag=e.target?.tagName?.toLowerCase();if(['input','textarea','select'].includes(tag)||e.target?.isContentEditable||$('themeModal').classList.contains('open'))return;if(e.key.toLowerCase()==='f'){e.preventDefault();toggleFocusMode()}else if(e.key.toLowerCase()==='a'){e.preventDefault();focusAdd()}}

window.addEventListener('keydown',handleAppShortcuts);



function storageWarning(message){let el=$('storageWarning');if(!el){el=document.createElement('div');el.id='storageWarning';el.setAttribute('role','status');el.style.cssText='position:fixed;bottom:12px;left:12px;z-index:100;max-width:440px;padding:10px 14px;background:#8b2626;color:white;border-radius:6px';document.body.appendChild(el)}el.textContent=message;el.hidden=false}



const safeStorage=createSafeStorage(storageWarning),read=safeStorage.read,write=safeStorage.write,validObject=isPlainObject,preserveRaw=safeStorage.preserveRaw;

function populateDateSelectors(){const ys=$('yearSelect'),ms=$('monthSelect'),today=new Date();ys.innerHTML='';for(let y=Math.min(today.getFullYear()-100,trackerState.year-2);y<=Math.max(today.getFullYear()+100,trackerState.year+2);y++){const o=document.createElement('option');o.value=y;o.textContent=y;ys.appendChild(o)}ys.value=trackerState.year;ms.value=trackerState.month}



function loadSavedData(){
  loadThemeSettings();
  setFocusMode(read('ht_focus_mode',false)===true,false);
  const rawHabits=read('ht_habits',[]),hasValidHabits=Array.isArray(rawHabits);
  if(!hasValidHabits){preserveRaw('ht_habits');storageWarning('Saved habits could not be validated. A recovery copy was kept.');trackerState.habits=[]}
  else{
    const validHabits=rawHabits.filter(x=>validObject(x)&&x.id&&typeof x.title==='string'&&x.title.trim());
    const malformedFields=validHabits.some(x=>(x.startDate&&!isValidLocalDate(x.startDate))||(x.scheduleStartDate&&!isValidLocalDate(x.scheduleStartDate))||(Array.isArray(x.schedule)&&x.schedule.some(day=>!Number.isInteger(day)||day<0||day>6))||(x.scheduleHistory&&!Array.isArray(x.scheduleHistory)));
    if(validHabits.length!==rawHabits.length||malformedFields)preserveRaw('ht_habits');
    trackerState.habits=validHabits.map(x=>({...x,emoji:x.emoji||'📌',schedule:Array.isArray(x.schedule)?[...new Set(x.schedule.filter(day=>Number.isInteger(day)&&day>=0&&day<=6))]:[0,1,2,3,4,5,6],scheduleHistory:Array.isArray(x.scheduleHistory)?x.scheduleHistory.filter(p=>isValidLocalDate(p.startDate)&&isValidLocalDate(p.endDate)&&Array.isArray(p.schedule)):[],startDate:isValidLocalDate(x.startDate)?x.startDate:'0001-01-01'}));
  }
  const rawArchived=read('ht_archived',[]);
  if(!Array.isArray(rawArchived)){preserveRaw('ht_archived');storageWarning('Archived habit data is invalid. A recovery copy was kept.');trackerState.archivedHabits=[]}
  else{trackerState.archivedHabits=rawArchived.filter(x=>validObject(x)&&x.id&&typeof x.title==='string');if(trackerState.archivedHabits.length!==rawArchived.length)preserveRaw('ht_archived')}
  trackerState.checksData=read('ht_checks',{});let invalidChecks=!validObject(trackerState.checksData);
  if(invalidChecks)trackerState.checksData={};
  else for(const[key,month]of Object.entries(trackerState.checksData)){
    if(!/^\d{1,4}-(?:[0-9]|1[01])$/.test(key)||!validObject(month)){trackerState.checksData[key]={};invalidChecks=true;continue}
    for(const[id,log]of Object.entries(month))if(!validObject(log)){delete month[id];invalidChecks=true}
  }
  if(invalidChecks){preserveRaw('ht_checks');storageWarning('Some completion records were invalid. A recovery copy was kept before invalid entries were skipped.')}
  const loadWellbeing=(key)=>{
    const value=read(key,{});let invalid=!validObject(value);
    if(invalid){preserveRaw(key);storageWarning(`Saved ${key==='ht_mood'?'mood':'sleep'} data is invalid. A recovery copy was kept.`);return{}}
    for(const[monthKey,month]of Object.entries(value)){
      if(!/^\d{1,4}-(?:[0-9]|1[01])$/.test(monthKey)||!validObject(month)){value[monthKey]={};invalid=true;continue}
      for(const[day,entry]of Object.entries(month)){
        const number=Number(entry),minimum=key==='ht_mood'?1:0,maximum=key==='ht_mood'?5:24;
        if(entry!==''&&(!Number.isInteger(Number(day))||Number(day)<1||Number(day)>31||!Number.isFinite(number)||number<minimum||number>maximum)){delete month[day];invalid=true}
      }
    }
    if(invalid){preserveRaw(key);storageWarning(`Some saved ${key==='ht_mood'?'mood':'sleep'} entries were invalid. A recovery copy was kept before invalid entries were skipped.`)}
    return value;
  };
  trackerState.moodData=loadWellbeing('ht_mood');trackerState.sleepData=loadWellbeing('ht_sleep');
  const rawNotes=read('ht_notes',[]);
  if(!Array.isArray(rawNotes)){preserveRaw('ht_notes');storageWarning('Saved notes are invalid. A recovery copy was kept.');trackerState.notes=[]}
  else{trackerState.notes=rawNotes.filter(x=>validObject(x)&&typeof x.text==='string');if(trackerState.notes.length!==rawNotes.length)preserveRaw('ht_notes')}
  let startDatesAdjusted=false;
  for(const h of [...trackerState.habits,...trackerState.archivedHabits]){const first=earliestCheckedDate(h.id,trackerState.checksData);if(first&&first<(h.startDate||'0001-01-01')){h.startDate=first;startDatesAdjusted=true}}
  if(startDatesAdjusted||hasValidHabits&&rawHabits.some(x=>validObject(x)&&(!Array.isArray(x.schedule)||!isValidLocalDate(x.startDate))))saveHabits();
  if(startDatesAdjusted)write('ht_archived',trackerState.archivedHabits);
  if(read('ht_schema_version',null)===null)write('ht_schema_version',2);
}

const saveHabits=()=>write('ht_habits',trackerState.habits);
const cloneRecords=(records)=>JSON.parse(JSON.stringify(records));
function persistHabitLists(previousHabits,previousArchived){
  if(!write('ht_habits',trackerState.habits)||!write('ht_archived',trackerState.archivedHabits)){
    trackerState.habits=previousHabits;trackerState.archivedHabits=previousArchived;
    // Best effort rollback if one side of the two-key move could not be stored.
    write('ht_habits',previousHabits);write('ht_archived',previousArchived);
    return false;
  }
  return true;
}

function saveChecks(){write('ht_checks',trackerState.checksData);write('ht_mood',trackerState.moodData);write('ht_sleep',trackerState.sleepData)}



const isT=d=>{const t=new Date();return t.getFullYear()===trackerState.year&&t.getMonth()===trackerState.month&&t.getDate()===d};

const isFuture=d=>dateFor(trackerState.year,trackerState.month,d)>dateFor(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());

function goToday(){const t=new Date();selectMonth(trackerState,t.getFullYear(),t.getMonth());populateDateSelectors();updateCalendar()}

function shiftMonth(delta){const d=new Date(trackerState.year,trackerState.month+delta,1);selectMonth(trackerState,d.getFullYear(),d.getMonth());populateDateSelectors();updateCalendar()}

function updateCalendar(){

  if(!selectMonth(trackerState,+$('yearSelect').value,+$('monthSelect').value))return;

  renderTableHeaders();renderTableBody();renderMentalMetrics();recalculateStatsAndCharts();renderChips();

}

function renderTableHeaders(){

  const n=getDaysInMonth(trackerState.year,trackerState.month),names=['Su','Mo','Tu','We','Th','Fr','Sa'];

  const weeks=getWeekRanges(trackerState.year,trackerState.month);

  $('hr1').innerHTML='<th class="nm">Habits</th>'+weeks.map((week,index)=>`<th colspan="${week.end-week.start+1}" class="wk">Week ${index+1}</th>`).join('')+(n<31?`<th colspan="${31-n}" class="wk empty-days" aria-hidden="true"></th>`:'')+'<th colspan="2" class="wk">This month</th>';


  let a=`<th class="nm">${trackerState.habits.length} habits</th>`,b='<th class="nm"></th>';

  for(let d=1;d<=31;d++){

    if(d<=n){a+=`<th>${names[new Date(trackerState.year,trackerState.month,d).getDay()]}</th>`;b+=`<th${isT(d)?' class="today-head" title="Today"':''}>${d}</th>`}

    else{a+='<th></th>';b+='<th></th>'}

  }

  a+='<th class="wk month-done-head">Done</th><th class="month-rate-head">Rate</th>';b+='<th class="wk month-done-head"></th><th class="month-rate-head"></th>';

  $('hr2').innerHTML=a;$('hr3').innerHTML=b;

}

function renderTableBody(){

  const tb=$('habitsTableBody'),n=getDaysInMonth(trackerState.year,trackerState.month),mk=getKey(trackerState.year,trackerState.month);

  tb.innerHTML='';

  if(!validObject(trackerState.checksData[mk]))trackerState.checksData[mk]={};

  trackerState.habits.forEach(h=>{

    if(!validObject(trackerState.checksData[mk][h.id]))trackerState.checksData[mk][h.id]={};

    const tr=document.createElement('tr');

    tr.innerHTML=`<td class="nm"><div class="hn"><span title="${esc(h.title)}"><em>${esc(h.emoji)}</em>&nbsp; ${esc(h.title)}</span><button aria-label="Move ${esc(h.title)} up" title="Move up" ${trackerState.habits.indexOf(h)===0?'disabled':''} onclick="reorderHabit('${h.id}',-1)">↑</button><button aria-label="Move ${esc(h.title)} down" title="Move down" ${trackerState.habits.indexOf(h)===trackerState.habits.length-1?'disabled':''} onclick="reorderHabit('${h.id}',1)">↓</button><button aria-label="Edit ${esc(h.title)}" title="Edit habit" onclick="editHabit('${h.id}')">✎</button><button aria-label="Archive ${esc(h.title)}" title="Archive habit" onclick="archiveHabit('${h.id}')">⇩</button><button aria-label="Delete ${esc(h.title)}" title="Delete habit" onclick="deleteHabit('${h.id}')">&times;</button></div></td>`;

    for(let d=1;d<=31;d++){

      const td=document.createElement('td');

      if(d<=n){

        const c=document.createElement('input');c.type='checkbox';c.className='chk';c.checked=!!trackerState.checksData[mk][h.id][d];const date=dateFor(trackerState.year,trackerState.month,d),future=isFuture(d),isScheduled=scheduled(h,date);c.disabled=!isScheduled;if(!isScheduled)td.className='off';else if(future)td.className='future';

        c.setAttribute('aria-label',`${h.title}, day ${d}${future?', future date; saved but excluded from progress until that date':''}`);if(future)c.title='Future date: you can pre-mark it, but it will not count toward progress until that date.';

        c.onchange=e=>toggleCheck(h.id,d,e.target.checked);

        td.appendChild(c);if(isT(d))td.className='today';

      }else td.className='off';

      tr.appendChild(td);

    }

    tr.insertAdjacentHTML('beforeend',`<td class="wk dn" id="d_${h.id}"></td><td class="rt" id="r_${h.id}"></td>`);

    tb.appendChild(tr);

  });

  if(!trackerState.habits.length){const tr=document.createElement('tr');tr.innerHTML='<td colspan="34" class="sub" style="text-align:left;padding:16px">No habits yet. Add one below to start tracking. Your tracker will stay empty until you choose a habit.</td>';tb.appendChild(tr)}

}

function toggleCheck(id,day,v){

  const mk=getKey(trackerState.year,trackerState.month);

  trackerState.checksData[mk]=trackerState.checksData[mk]||{};trackerState.checksData[mk][id]=trackerState.checksData[mk][id]||{};

  trackerState.checksData[mk][id][day]=v;

  const habit=trackerState.habits.find(h=>h.id===id),date=localISO(dateFor(trackerState.year,trackerState.month,day));

  if(v&&habit&&date<(habit.startDate||'0001-01-01')){habit.startDate=date;saveHabits()}

  saveChecks();recalculateStatsAndCharts();

}

function renderMentalMetrics(){renderWellbeing({year:trackerState.year,month:trackerState.month,moodData:trackerState.moodData,sleepData:trackerState.sleepData,isFuture,save:()=>{saveChecks();recalculateStatsAndCharts()},css,warn:storageWarning,$})}

function monthlyReportData(year=trackerState.year,month=trackerState.month){return buildMonthlyReportData({habits:trackerState.habits,archivedHabits:trackerState.archivedHabits,checksData:trackerState.checksData,moodData:trackerState.moodData,sleepData:trackerState.sleepData,year,month,now:new Date()})}

function downloadMonthlyReport(){

  const r=monthlyReportData(),gradeTone=r.grade.mark==='A+'||r.grade.mark==='A'?'great':r.grade.mark==='N/A'?'none':'grade';

  const pct=v=>v===null?'—':`${v}%`,bar=v=>v===null?'0%':`${v}%`;

  const habitsHtml=r.rows.length?r.rows.map(h=>`<tr><td><span class="habit-icon">${esc(h.emoji)}</span><strong>${esc(h.title)}</strong>${h.category?`<small>${esc(h.category)}</small>`:''}</td><td>${h.done} / ${h.goal}</td><td>${h.missed}</td><td><div class="track"><i style="width:${bar(h.percent)}"></i></div><span class="percent">${pct(h.percent)}</span></td><td><b class="mini-grade">${h.grade.mark}</b></td></tr>`).join(''):'<tr><td colspan="5" class="empty">No habits are available for this month yet.</td></tr>';

  const report=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(r.monthLabel)} Habit Progress Report</title><style>

*{box-sizing:border-box}body{margin:0;padding:40px 18px;background:#f3f5f7;color:#20252c;font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.report{max-width:900px;margin:auto;background:#fff;border:1px solid #d7dce2;border-radius:16px;padding:34px;box-shadow:0 14px 44px #11131812}header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}h1{font-size:28px;line-height:1.15;margin:0 0 6px;letter-spacing:-.03em}.muted{color:#5b6470}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;font-weight:700;color:#667080}.print{border:0;border-radius:8px;background:#364152;color:white;padding:10px 14px;font:inherit;font-weight:650;cursor:pointer}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:26px 0}.card{padding:16px;border:1px solid #dfe3e8;border-radius:11px;background:#fafbfc}.card span{display:block;font-size:12px;color:#5b6470}.card strong{display:block;margin-top:3px;font-size:25px;line-height:1.15}.grade-card{background:#f3f0ff;border-color:#ded5fa}.grade-card strong{color:#6046a7}.grade-card.great{background:#edf7f0;border-color:#cde5d4}.grade-card.great strong{color:#287249}.grade-card.none{background:#f3f5f7}.progress-line{height:10px;border-radius:10px;background:#e6e9ed;overflow:hidden;margin-top:12px}.progress-line i,.track i{display:block;height:100%;border-radius:inherit;background:#557c66}h2{font-size:17px;margin:27px 0 10px}table{width:100%;border-collapse:collapse;font-size:13px}th{text-align:left;color:#5b6470;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em}td,th{padding:11px 8px;border-bottom:1px solid #e6e9ed}td:first-child{width:34%}td:first-child small{display:block;color:#69727e;margin-left:26px}.habit-icon{display:inline-block;width:22px}.track{display:inline-block;vertical-align:middle;width:min(100px,55%);height:7px;border-radius:9px;background:#e6e9ed;overflow:hidden;margin-right:7px}.track i{background:#557c66}.percent{color:#5b6470}.mini-grade{display:inline-block;min-width:34px;padding:3px 7px;background:#f0f2f5;border-radius:6px;text-align:center}.empty{text-align:center;color:#5b6470;padding:24px}.notes{margin-top:23px;padding:14px 16px;border-radius:10px;background:#f6f7f9;color:#515b67;font-size:13px}.notes p{margin:4px 0}.footer{margin-top:26px;padding-top:14px;border-top:1px solid #e6e9ed;color:#69727e;font-size:11px}@media(max-width:620px){body{padding:12px 8px}.report{padding:20px 14px}.summary{grid-template-columns:repeat(2,1fr)}header{align-items:flex-start}h1{font-size:23px}table{font-size:11px}td,th{padding:9px 4px}.track{width:42px}}@media print{body{padding:0;background:#fff}.report{max-width:none;border:0;border-radius:0;box-shadow:none;padding:0}.print{display:none}.summary{break-inside:avoid}tr{break-inside:avoid}}

</style></head><body><main class="report"><header><div><div class="eyebrow">Habit Tracker · Monthly Report</div><h1>${esc(r.monthLabel)}</h1><p class="muted">${r.endDay?`Progress through ${new Intl.DateTimeFormat(undefined,{month:'short',day:'numeric',year:'numeric'}).format(dateFor(r.year,r.month,r.endDay))}`:'No days in this month have occurred yet.'}</p></div><button class="print" onclick="window.print()">Print / Save as PDF</button></header>

<section class="summary"><div class="card"><span>Progress</span><strong>${pct(r.percent)}</strong><div class="progress-line"><i style="width:${bar(r.percent)}"></i></div></div><div class="card"><span>Completed</span><strong>${r.done}</strong></div><div class="card"><span>Scheduled goal</span><strong>${r.goal}</strong></div><div class="card grade-card ${gradeTone}"><span>Monthly mark</span><strong>${r.grade.mark}</strong><span>${esc(r.grade.label)}</span></div></section>

<h2>Habit breakdown</h2><table><thead><tr><th>Habit</th><th>Done / goal</th><th>Missed</th><th>Progress</th><th>Mark</th></tr></thead><tbody>${habitsHtml}</tbody></table>

<h2>Wellbeing logs</h2><p class="muted">${r.moodAverage===null?'Mood: no valid ratings':`Average mood: ${r.moodAverage.toFixed(1)} / 5`} &nbsp;·&nbsp; ${r.sleepAverage===null?'Sleep: no valid entries':`Average sleep: ${r.sleepAverage.toFixed(1)} hours`}</p>

<aside class="notes"><strong>How this report is scored</strong><p>Progress = completed scheduled habit-days ÷ eligible scheduled habit-days. Only dates on or before the report cutoff count; future dates and rest days are excluded. Missed = scheduled goal minus completed.</p><p>Marks: A+ 95–100%, A 90–94%, B 80–89%, C 70–79%, D 60–69%, F below 60%. A month with no eligible days receives N/A.</p></aside><div class="footer">Generated ${esc(new Intl.DateTimeFormat(undefined,{dateStyle:'long'}).format(new Date()))}. Mood and sleep averages include valid recorded values only and are descriptive summaries.</div></main></body></html>`;

  try{const blob=new Blob([report],{type:'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`habit-report-${r.year}-${String(r.month+1).padStart(2,'0')}.html`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch(e){storageWarning('Could not create the monthly report download in this browser.');}

}

function recalculateStatsAndCharts(){

  const a=calculateDashboardAnalytics({habits:trackerState.habits,checksData:trackerState.checksData,sleepData:trackerState.sleepData,year:trackerState.year,month:trackerState.month,now:new Date()});

  $('statGoal').textContent=a.monthGoal;$('statCompleted').textContent=a.done;$('statLeft').textContent=a.remaining;$('donutPercent').textContent=Math.round(a.overallPercent)+'%';$('donutSub').textContent=a.monthGoal?`${a.done} done · ${a.planned} plan`:'No eligible scheduled habits';

  $('statGoal').title='All eligible scheduled habit-days in this month, including clearly labeled planned goals';$('statCompleted').title='Completed scheduled days through today';$('statLeft').title='Scheduled days not completed or pre-marked';

  $('avgDailyRate').textContent='Avg '+Math.round(a.averageDailyRate)+'%';$('statStreak').textContent=a.currentStreak+'d';$('statStreak').title='Longest current streak among active habits';

  charts?.update({dailyBars:a.dailyBars,dailyAverage:a.dailyAverage,plannedDays:a.plannedDays,weekly:a.weekly,overallPercent:a.overallPercent});renderAnalysisTable(a.habitStats);renderTopHabits(a.highlights);

}

function renderAnalysisTable(st){

  st.forEach(x=>{

    const d=$('d_'+x.id),r=$('r_'+x.id);if(!d)return;

    d.innerHTML=`<b>${x.actual}</b>/${x.goal}<span class="sub" title="Current streak ${x.currentStreak} days; best ${x.bestStreak} days"> · ${x.currentStreak}d</span>`;

    const displayRate=Math.round(x.percentage);

    r.innerHTML=`<span class="bar"><i style="width:${x.percentage}%"></i></span><span class="pc">${x.goal?`${displayRate}%`:'—'}</span>`;

  });

}

function renderTopHabits(highlights){
  const top=highlights.topHabits.length?highlights.topHabits.map((item,index)=>`<li><span class="t"><s>${index+1}</s><em>${esc(item.emoji)}</em> ${esc(item.title)}</span><span class="v"><strong>${item.goal?`${Math.round(item.percentage)}%`:'—'}</strong><span class="bar"><i style="width:${item.percentage}%"></i></span></span></li>`).join(''):'<li class="sub">Add your first habit below to start tracking.</li>';
  const names=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const li=(title,value,detail)=>`<li><span class="t">${title}</span><span class="v"><strong>${value}</strong><span class="sub">${detail}</span></span></li>`;
  const day=highlights.bestWeekday?li('Best weekday',names[highlights.bestWeekday.weekday],`${Math.round(highlights.bestWeekday.average)}% done on average`):li('Best weekday','–','Log a few eligible days');
  const comparison=highlights.sleepComparison;
  const sleep=comparison?li('Sleep 7h+ comparison',`${comparison.difference>0?'+':''}${Math.round(comparison.difference)}%`,`descriptive · ${comparison.restedNights} longer vs ${comparison.shorterNights} shorter nights`):li('Sleep 7h+ comparison','–','Log more nights to compare');
  $('topHabitsList').innerHTML=top+day+sleep;
}

/* ---------- Habits & theme ---------- */

function addHabits(text){

  const list=parseHabits(text);if(!list.length){storageWarning('Enter a habit name or paste a list of names.');return false;}
  const result=addHabitsToState(trackerState,list,localISO(new Date()));
  if(!result.added.length){storageWarning(`No habits added. Already exists: ${result.duplicates.join(', ')}.`);return false;}
  if(!saveHabits()){trackerState.habits.splice(-result.added.length,result.added.length);return false;}
  updateCalendar();
  if(result.duplicates.length)storageWarning(`Added ${result.added.length}. Skipped duplicates: ${result.duplicates.join(', ')}.`);
  const sc=$('habitsTable').closest('.scroll');sc.scrollTop=sc.scrollHeight;return true;

}

function submitAdd(){const i=$('addInput');if(addHabits(i.value)){i.value='';const b=document.querySelector('.addbtn');b.textContent='Added';setTimeout(()=>b.textContent='Add habit',1100)}i.focus()}

function focusAdd(){$('addInput').focus()}

function renderChips(){

  const have=new Set(trackerState.habits.map(h=>normalizeHabitName(h.title)));

  $('chips').innerHTML=SUGGEST.filter(t=>!have.has(normalizeHabitName(t))).slice(0,4).map(t=>`<button class="chip" onclick="addHabits('${t}')">+ ${t}</button>`).join('');

}

$('addInput').addEventListener('paste',e=>{const t=(e.clipboardData||window.clipboardData).getData('text');if(/[\n,;]/.test(t)){e.preventDefault();addHabits(t)}});

function editHabit(id){const h=trackerState.habits.find(x=>x.id===id);if(!h)return;const name=prompt('Habit name:',h.title);if(name===null)return;const schedule=prompt('Scheduled weekdays (0=Sun … 6=Sat), comma separated. Omit rest days:',(h.schedule||[0,1,2,3,4,5,6]).join(','));if(schedule===null)return;const emoji=prompt('Habit icon (emoji):',h.emoji||'📌');if(emoji===null)return;const category=prompt('Category (optional):',h.category||'');if(category===null)return;const previous=cloneRecords(trackerState.habits),result=editHabitInState(trackerState,id,{title:name,schedule:schedule.split(','),emoji,category},localISO(new Date()));if(!result.ok){storageWarning(result.error);return}if(!saveHabits()){trackerState.habits=previous;return}updateCalendar()}

function archiveHabit(id){const h=trackerState.habits.find(x=>x.id===id);if(!h||!confirm(`Archive “${h.title}”? Historical records will be kept.`))return;const previousHabits=cloneRecords(trackerState.habits),previousArchived=cloneRecords(trackerState.archivedHabits);archiveHabitInState(trackerState,id,localISO(new Date()));if(!persistHabitLists(previousHabits,previousArchived))return;updateCalendar()}

function restoreHabit(){if(!trackerState.archivedHabits.length){storageWarning('There are no archived habits.');return}const choices=trackerState.archivedHabits.map((h,i)=>`${i+1}. ${h.title}`).join('\n'),pick=Number(prompt(`Restore an archived habit by number:\n${choices}`));if(!Number.isInteger(pick)||pick<1||pick>trackerState.archivedHabits.length)return;const previousHabits=cloneRecords(trackerState.habits),previousArchived=cloneRecords(trackerState.archivedHabits),id=trackerState.archivedHabits[pick-1].id,result=restoreHabitInState(trackerState,id,localISO(new Date()));if(!result.ok){storageWarning(result.error);return}if(!persistHabitLists(previousHabits,previousArchived))return;updateCalendar()}

function deleteHabit(id){const h=trackerState.habits.find(x=>x.id===id);if(!h||!confirm(`Permanently remove “${h.title}” from this tracker? Historical completion records will be retained.`))return;const previous=cloneRecords(trackerState.habits);deleteHabitFromState(trackerState,id);if(!saveHabits()){trackerState.habits=previous;return}updateCalendar()}

function reorderHabit(id,delta){const previous=cloneRecords(trackerState.habits);if(!reorderHabitInState(trackerState,id,delta))return;if(!saveHabits()){trackerState.habits=previous;return}updateCalendar()}

function toggleTheme(){

  const appearance=trackerState.themeSettings.appearance==='dark'?'light':'dark',p=THEME_PALETTES[trackerState.themeSettings.preset][appearance];trackerState.themeSettings={...trackerState.themeSettings,appearance,background:p[0],surface:p[1]};applyTheme(trackerState.themeSettings);write('ht_theme_settings',trackerState.themeSettings);write('ht_theme',appearance);if(trackerState.themeDraft){trackerState.themeDraft={...trackerState.themeSettings};syncThemeControls(trackerState.themeDraft)}

}



/* ---------- Quick notes ---------- */



const saveNotes=()=>write('ht_notes',trackerState.notes);

function renderNotes(){

  const n=trackerState.notes.length,b=$('noteBadge');

  b.textContent=n>99?'99+':n;b.classList.toggle('show',n>0);

  $('noteCount').textContent=n?'('+n+')':'';

  $('noteList').innerHTML=n?trackerState.notes.map(x=>`<li><div class="nt">${esc(x.text)}<small>${esc(x.date)}</small></div><button onclick="deleteNote('${x.id}')" aria-label="Delete note" title="Delete">&times;</button></li>`).join(''):'<li class="npempty">No notes yet. Jot down a small task above.</li>';

}

function addNote(){

  const i=$('noteInput'),t=i.value.trim();

  if(t){trackerState.notes.unshift({id:'n_'+Date.now()+'_'+Math.random().toString(36).slice(2,5),text:t,date:new Date().toLocaleDateString('en-GB',{day:'numeric',month:'short'})});saveNotes();renderNotes();i.value=''}

  i.focus();

}

function deleteNote(id){trackerState.notes=trackerState.notes.filter(x=>x.id!==id);saveNotes();renderNotes()}

function toggleNotes(e){

  if(e)e.stopPropagation();

  const p=$('notePop'),open=!p.classList.contains('open');

  p.classList.toggle('open',open);$('noteBtn').setAttribute('aria-expanded',open);

  if(open)setTimeout(()=>$('noteInput').focus(),0);else $('noteBtn').focus();

}

document.addEventListener('click',e=>{const p=$('notePop');if(p.classList.contains('open')&&!e.target.closest('.notewrap'))toggleNotes()});

document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('notePop').classList.contains('open'))toggleNotes()});

trackerState.notes=read('ht_notes',[]);renderNotes();

function initialize(){loadSavedData();charts=createCharts({css,warn:storageWarning});charts.rebuild();populateDateSelectors();updateCalendar()}

if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize,{once:true});else initialize();



function exportAppData(){try{const blob=new Blob([JSON.stringify(exportLocalData(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`habit-tracker-backup-${localISO(new Date())}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch{storageWarning('Could not export Habit Tracker data in this browser.')}}

function openImportPicker(){$('importDataInput').click()}

async function handleImportFile(event){const file=event.target.files?.[0];if(!file)return;try{const payload=JSON.parse(await file.text());let allowReplace=false;try{allowReplace=confirm('Importing replaces the Habit Tracker data in this browser. A recovery backup will be saved first. Continue?')}catch{}importLocalData(payload,localStorage,{allowReplace});alert('Habit Tracker data imported. The page will reload now.');location.reload()}catch(error){storageWarning(error.message||'Could not import this backup. Existing data was preserved.')}finally{event.target.value=''}}

$('importDataInput')?.addEventListener('change',handleImportFile);

Object.assign(window,{toggleNotes,addNote,shiftMonth,updateCalendar,toggleTheme,openThemeSettings,goToday,downloadMonthlyReport,toggleFocusMode,restoreHabit,focusAdd,submitAdd,closeThemeSettings,resetThemeDraft,saveThemeSettings,editHabit,archiveHabit,deleteHabit,reorderHabit,addHabits,deleteNote,exportAppData,openImportPicker});


